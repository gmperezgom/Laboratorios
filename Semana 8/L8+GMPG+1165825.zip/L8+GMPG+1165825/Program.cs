﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L8_GMPG_1165825
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("LAB 8- GERBER PEREZ");
            int opcion;
            Console.WriteLine("Ingrese la opcion que deseas calcular");
            Console.WriteLine("1.Sumatoria, 2. Factorial, 3. Tablas de multiplicar, 4. Salir");
            opcion =Convert.ToInt32(Console.ReadLine());

            if (opcion > 0 && opcion < 4) {
                switch (opcion)
                {
                    case 1:
                        int numero = 0;
                        int i = 1;
                        int suma = 0;
                        Console.WriteLine("Ingresa un numero");
                        numero = Convert.ToInt32(Console.ReadLine());
                        do
                        {
                            suma = i + suma;
                            i++;
                        }
                        while (i <= numero);
                        Console.WriteLine("El resultado de la suma es:" + suma);
                        break;
                    case 2:
                        int factorial = 1;
                        Console.WriteLine("Ingresa un numero");
                        int numero2 = Convert.ToInt32(Console.ReadLine());

                        for (int i2 = 1; i2 <= numero2; i2++)
                        {
                            factorial = i2 * factorial;
                        }
                        Console.WriteLine("El factorial es: " + factorial);
                        break;
                     case 3:
                        for (int j = 1; j <= 10; j++)
                        {
                            Console.WriteLine(j);
                            string resultado= "";
                            for (int k = 1; k <= 10; k++)
                            {

                                resultado += "\t" + j * k;
                            }
                            Console.WriteLine(resultado);
                        }
                        break;
                }
            }
            else
            {
                Console.WriteLine("Opcion invalida");
                Console.ReadKey();
            }
            Console.ReadKey();
        }
    }
}
