﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_GMPG_1165825
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese una frase: ");
            string frase = Console.ReadLine();

            //Cantidad de palabras en una frase
            string[] c= frase.Split(' ');
            Console.WriteLine($"La cantidad de palabras es: {c.Length}");

            //Cantidad de vocales en una frase
            int i = 0;
            foreach (char v in frase)
            {
                if (v== 'a' || v== 'e' || v=='i' || v=='o'|| v=='u'|| v == 'A' || v == 'E' || v == 'I' || v == 'O' || v == 'U')
                {
                     i++;
                }
            }
            Console.WriteLine($"La cantidad de vocales es:  {i}");
            // La frase en orden inverso
            string fraseInvertida = new string(frase.Reverse().ToArray());
            Console.WriteLine($"La frase invertida es: {fraseInvertida}");
            
            
            // La frase sin espacios
            string fraseSinEspacios = frase.Replace(" ", "");
            Console.WriteLine($"Frase sin espacios: {fraseSinEspacios}");

            //Determinar si la frase es palindroma
            string invertidasinespacios = fraseInvertida.Replace(" ","");
            string invertidasinespaciosMin = invertidasinespacios.ToLower();
            string frasesinespaciosMin= fraseSinEspacios.ToLower();
            if (invertidasinespaciosMin==frasesinespaciosMin)
            {
                Console.WriteLine("La frase es palindroma");
            }
            else
            {
                Console.WriteLine("La frase no es palindroma");
            }
        }
    }
}
