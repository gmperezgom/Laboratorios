﻿class L7GMPG {
    static void Main(string[] args) {

        int a = 0, b = 1, c = 0, i = 2;
        int N = 0, resultado=0;

        Console.WriteLine("Ingrese el numero ");
        N= Convert.ToInt32(Console.ReadLine());

        if (N > 0)
        {
            resultado = resultado+a;
            if (N > 1)
            {
                resultado = resultado + b;
            }
            else
            {
                Console.WriteLine("El resultado es"+resultado);
            }
            while (i < N)
            {
                c = a + b;
                resultado = resultado + c;
                a = b;
                b = c;

                i = i+1;
            }
            Console.WriteLine("El resultado es: " + resultado);
        }
        else
        {
            Console.WriteLine("El resultado es "+resultado);
        }

    }
}