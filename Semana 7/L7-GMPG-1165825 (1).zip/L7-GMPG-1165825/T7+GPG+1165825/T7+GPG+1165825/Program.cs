﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T7_GPG_1165825
{
    public class Program
    {
        static void Main(string[] args)
        {
            int n = 0, a = 0, x = 0, i = 1, k = 0;
            double res1 = 0, res2 = 0, res3 = 0;

            Console.WriteLine("Ingrese un numero");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el valor de a");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el valor de x");
            x = Convert.ToInt32(Console.ReadLine());

            if (n > 0)
            {
                while (i <= n)
                {
                    res1 = res1 + (1.0 / i);
                    res2 = res2 + (1.0 / Math.Pow(2, i));
                    res3= res3+ (Math.Pow(x, i)*(Math.Pow(a, i-1)));

                    i++;
                }
                Console.WriteLine("El resultado de (1 / 1) + (1 / 2) + (1 / 3) + … + (1 / N) es: " + res1);
                Console.WriteLine("El resultado de (1 / 2^1) + (1 / 2^2) + (1 / 2^3) + … + (1 / 2^N) es: " + res2);
                Console.WriteLine("El resultado de la tercera operación es: " + res3);
            }
            else
            {
                Console.WriteLine("Ingrese datos validos");
            }

        }
    }
}
