﻿class L10_semana10 {
    static void Main(string[] args) {
        int num;
        Random rand = new Random();
        int numeroRandom = rand.Next(1, 101);
        bool valor=true;

        for (int i = 1; i < 100; i++)
        {
                Console.WriteLine("Ingresa un numero entre 1 y 100");
                num = Convert.ToInt32(Console.ReadLine());
            if (num <= 100 && num >= 1) { 
                valor = true;
                if (num < numeroRandom)
                {
                    Console.WriteLine("El numero es mayor");
                }
                else if (num > numeroRandom)
                {
                    Console.WriteLine("El numero es menor");
                }
                else
                {
                    Console.WriteLine("Has acertado el numero " + numeroRandom);
                    Console.WriteLine("Lo hiciste " + i + " intentos");
                    break;
                }
            }
            else
            {
                valor = false;
            }
            while (!valor)
            {
                Console.WriteLine("Ingresa un valor válido");
                break;
            }
        }
    }
    
}