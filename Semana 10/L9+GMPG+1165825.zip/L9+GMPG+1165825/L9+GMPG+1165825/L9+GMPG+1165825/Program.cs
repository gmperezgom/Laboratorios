﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_GMPG_1165825
{
    class automovil {
        private int modelo;
        private double precio;
        private string marca;
        private bool disponibilidad;
        private double tipoCambioDolar;
        private double descuentoAplicado;

        public automovil(){
            modelo =2019;
            precio = 10000.00;
            marca ="";
            disponibilidad = false;
            tipoCambioDolar = 7.50;
            descuentoAplicado = 0.00;
        }
        public void DefinirModelo(int Modelo)
        {
            this.modelo = Modelo;
        }

        public void DefinirPrecio(double Precio)
        {
            this.precio = Precio;
        }

        public void DefinirMarca(string Marca)
        {
            this.marca = Marca;
        }

        public void DefinirTipoCambio(double TipoCambio)
        {
            this.tipoCambioDolar = TipoCambio;
        }
        public void CambiarDisponibilidad()
        {
            if (disponibilidad)
            {
                disponibilidad = false;
            }
            else
            {
                disponibilidad = true; 
            }
        }
        public string MostrarDisponibilidad()
        {
            if (disponibilidad)
            {
                return "Disponible";
            }
            else
            {
                return "No se encuentra disponible actualmente";
            }
        }
        public string MostrarInformacion()
        {
            return $"Marca: {marca}. Modelo: {modelo}. Precio de venta: Q{precio}. Precio en dólares: ${precio/tipoCambioDolar}. {MostrarDisponibilidad()}";
        }

        public void AplicarDescuento(double Descuento)
        {
            this.descuentoAplicado = Descuento;
            double nuevoPrecio = precio - Descuento;
            DefinirPrecio(nuevoPrecio);
        }
    }
    public class Automovil
    {
        static void Main(string[] args)
        {
            automovil objAutomovil= new automovil();

            Console.WriteLine("Ingrese el modelo del Automovil: ");
            int modelo = Convert.ToInt32(Console.ReadLine());
            objAutomovil.DefinirModelo(modelo);

            Console.WriteLine("Ingrese el precio del automovil en quetzales");
            double precio=Convert.ToDouble(Console.ReadLine());
            objAutomovil.DefinirPrecio(precio);

            Console.WriteLine("Ingresa la marca del automovil: ");
            string marca= Console.ReadLine();
            objAutomovil.DefinirMarca(marca);

            Console.WriteLine("Ingresa el tipo de cambio del dolar: ");
            double cambio=Convert.ToDouble(Console.ReadLine());
            objAutomovil.DefinirTipoCambio(cambio);

            Console.WriteLine("\n Información del automovil: ");
            Console.WriteLine(objAutomovil.MostrarInformacion());

            Console.Write($"\nDesea cambiar disponibilidad (Disponibilidad actual: {objAutomovil.MostrarDisponibilidad()})? (si/no): ");
            string respuesta = Console.ReadLine().ToLower();
            if (respuesta == "si")
            {
                objAutomovil.CambiarDisponibilidad();
            }
            Console.WriteLine("\nInformación actualizada del automóvil:");
            Console.WriteLine(objAutomovil.MostrarInformacion());

            Console.Write("\nIngrese el monto de descuento a aplicar: ");
            double descuento = Convert.ToDouble(Console.ReadLine());
            objAutomovil.AplicarDescuento(descuento);

            Console.WriteLine("\nInformación final del automóvil después del descuento:");
            Console.WriteLine(objAutomovil.MostrarInformacion());
        }
    }
}
