﻿
using System;

namespace T7_GMPG_1165825
{
    public class Program
    {
        static void Main(string[] args)
        {
            int año=0, dia = 0, mes = 0,diasm = 0; ;

            Console.WriteLine("Ingrese año de nacimiento");
            año=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el mes de su nacimiento");
            mes=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el dia de su nacimiento");
            dia=Convert.ToInt32(Console.ReadLine());

            switch (mes)
            {
                case 1:
                    diasm = 31;
                break;
                case 2:
                    diasm = 28;
                break;
                case 3:
                    diasm = 31;
                break;
                case 4:
                    diasm = 30;
                break;
                case 5:
                    diasm = 31;
                break;
                case 6:
                    diasm = 30;
                break;
                case 7:
                    diasm = 31;
                break;
                case 8:
                    diasm = 31;
                break;
                case 9:
                    diasm = 30;
                break;
                case 10:
                    diasm = 31;
                    break;
                case 11:
                    diasm = 30;
                    break;
                case 12:
                    diasm = 31;
                    break;
            }
            if (dia > diasm)
            {
                Console.WriteLine("Día inválido para el mes ingresado.");
            }
            else if (mes > 12)
            {
                Console.WriteLine("Mes invalido");
            }
            else if (mes == 3 && dia >= 21 || mes == 4 && dia <= 19)
            {
                Console.WriteLine("Su signo zodiacal es: Aries ");
            }
            else if (mes == 4 && dia >= 20 || mes == 5 && dia <= 20)
            {
                Console.WriteLine("Su signo zodiacal es: Tauro ");
            }
            else if (mes == 5 && dia >= 21 || mes == 6 && dia <= 20)
            {
                Console.WriteLine("Su signo zodiacal es: Géminis ");
            }
            else if (mes == 6 && dia >= 21 || mes == 7 && dia <= 22)
            {
                Console.WriteLine("Su signo zodiacal es: Cancer ");
            }
            else if (mes == 7 && dia >= 23 || mes == 8 && dia <= 22)
            {
                Console.WriteLine("Su signo zodiacal es: Leo ");
            }
            else if (mes == 8 && dia >= 23 || mes == 9 && dia <= 22)
            {
                Console.WriteLine("Su signo zodiacal es: Virgo ");
            }
            else if (mes == 9 && dia >= 23 || mes == 10 && dia <= 22)
            {
                Console.WriteLine("Su signo zodiacal es: Libra ");
            }
            else if (mes == 10 && dia >= 23 || mes == 11 && dia <= 21)
            {
                Console.WriteLine("Su signo zodiacal es: Escorpio ");
            }
            else if (mes == 11 && dia >= 22 || mes == 12 && dia <= 21)
            {
                Console.WriteLine("Su signo zodiacal es: Sagitario ");
            }
            else if (mes == 12 && dia >= 22 || mes == 1 && dia <= 19)
            {
                Console.WriteLine("Su signo zodiacal es: Capricornio ");
            }
            else if (mes == 1 && dia >= 20 || mes == 2 && dia <= 18)
            {
                Console.WriteLine("Su signo zodiacal es: Acuario ");
            }
            else if (mes == 2 && dia >= 19 || mes == 3 && dia <= 20)
            {
                Console.WriteLine("Su signo zodiacal es: Acuario ");
            }
        }
    }
}
