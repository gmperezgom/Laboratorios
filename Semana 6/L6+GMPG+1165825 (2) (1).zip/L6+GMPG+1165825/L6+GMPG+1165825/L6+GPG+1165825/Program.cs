﻿class ejer2L6GMPG1165825
{
    static void Main(string[] args) {
        Console.WriteLine("Ejercicio 2");
        int a = 0, b = 0, c = 0;

        Console.WriteLine("Ingrese el numero uno: ");
        a = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese el numero dos: ");
        b = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese el numero tres: ");
        c = Convert.ToInt32(Console.ReadLine());


        if (a < 0)
        {
            Console.WriteLine("Ingrese datos validos");
        }
        else if (b < 0)
        {
            Console.WriteLine("Ingrese datos validos");
        }
        else if (c < 0)
        {
            Console.WriteLine("Ingrese datos validos");
        }

        if (a > b) {
            if (a > c)
            {
                Console.WriteLine("El numero mayor es el primero");
            }
            else if (a == c)
            {
                Console.WriteLine("Los numeros uno y tres son mayores");
            }
            else
            {
                Console.WriteLine("El numero mayor es el 3");
            }
        }

        else if (a == b)
        {
            if (a > c)
            {
                Console.WriteLine("Los numeros uno y dos son mayores");
            }
            else
            {
                Console.WriteLine("El numero mayor es el 3");
            }
        }

        else if (a == c)
        {
            if (b > c)
            {
                Console.WriteLine("El numero mayor es el dos ");
            }

        }
        else if (b == c)
        {
            Console.WriteLine("Los numeros dos y tres son mayores");
        }

    }
}
