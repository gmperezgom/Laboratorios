﻿class Program
{
    static void Main(string[] args) {

        Console.WriteLine("Ingresa tu nombre: ");
        string Nombre= Console.ReadLine();

        Console.WriteLine("Hola mundo");
        Console.WriteLine("soy "+Nombre);

        /*La diferencia entre Console.Writeline y Console.Write, es que WriteLine almacena los valores en diferentes líneas y Write lo almacena en una sola línea*/
        Console.Write("Hola Mundo");
        Console.Write("soy "+Nombre);
        Console.ReadKey();

    }
}