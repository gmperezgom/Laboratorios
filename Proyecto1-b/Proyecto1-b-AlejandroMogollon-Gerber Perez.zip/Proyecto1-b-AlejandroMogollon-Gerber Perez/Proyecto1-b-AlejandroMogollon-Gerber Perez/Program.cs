﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto1_b_AlejandroMogollon_Gerber_Perez
{
    class Program
    {
        static void Main()
        {
            //Declaracion de las variables
            int personajeSeleccion = 0, camino = 0, lucha = 0, enemigosDerrotados = 0,
            enemigoVida = 0, cantidadBandidos = 0, cantidadMonstruos = 0;
            string nickname = "";
            bool jugar = true;
            Personaje personaje = null;
            do
            {
                //Ingreso del usuario
                Console.WriteLine("Ingrese su nombre de usuario:");
                nickname = Console.ReadLine();
                while (jugar == true)
                {
                    //Selección del personaje
                    Console.Write($"\n{nickname} selecciona tu personaje.\n1. Mago\t\t\t\t\t2. Caballero\t\t\t\t3. Arquera" +
                    $"\nPuntos de vida: 100\t\t\tPuntos de vida: 70\t\t\tPuntos de vida: 85" +
                    $"\nPoder de ataque: 20\t\t\tPoder de ataque: 30\t\t\tPoder de ataque: 25\n");
                    personajeSeleccion = Convert.ToInt32(Console.ReadLine());
                    //Se inicializa como null para que no obtenga cualquier valor 


                    //Elección entre las opciones de los personajes
                    switch (personajeSeleccion)
                    {
                        case 1:
                            personaje = new Personaje("Mago", 100, 20);
                            break;
                        case 2:
                            personaje = new Personaje("Caballero", 70, 30);
                            break;
                        case 3:
                            personaje = new Personaje("Arquera", 85, 25);
                            break;
                        default:
                            Console.WriteLine("Selecciona un personaje válido.");
                            continue;

                    }
                    break;
                }
                while (jugar == true)
                {
                    //Elección del camino
                    Console.WriteLine($"\n{nickname} elige tu camino.\n1. Bosque Oscuro\n2. Cueva Sombría\n3. Camino de Piedra");
                    camino = Convert.ToInt32(Console.ReadLine());
                    //Elección entre las opciones del camino
                    switch (camino)
                    {
                        case 1:
                            Console.WriteLine($"Bosque Oscuro\t\t\t\t\t\t\t{personaje.MostrarInformacion()}");

                            while (personaje.puntosVida > 0 && enemigosDerrotados < 3 && cantidadBandidos < 3 && cantidadMonstruos < 3)
                            {
                                Console.WriteLine($"¡Oye {nickname}! Te has encontrado un enemigo.");

                                if (enemigosDerrotados == 0)
                                {
                                    Console.WriteLine("¡Te has encontrado con un BANDIDO!");
                                    //Declaracion del ataque random del enemigo
                                    Random rand1 = new Random();
                                    int ataqueEnemigo1 = rand1.Next(5, 21);
                                    //Declaracion de la vida del enemigo
                                    enemigoVida = 30;

                                    //Se muestran las estadisticas del enemigo
                                    Console.WriteLine($"\n\tEL enemigo cuenta con {enemigoVida} puntos de vida y {ataqueEnemigo1} puntos de ataque.");

                                    Console.WriteLine("\n\t¿Qué deseas hacer?\n1. Luchar\n2. Huir");
                                    lucha = Convert.ToInt32(Console.ReadLine());

                                    //Proceso para la lucha
                                    if (lucha == 1)
                                    {
                                        while (personaje.puntosVida > 0 && enemigoVida > 0)
                                        {
                                            //Ataque del personaje hacia el enemigo
                                            enemigoVida = enemigoVida - personaje.poderAtaque;
                                            Console.WriteLine("");
                                            Console.WriteLine($"\t\t¡Le has infringido {personaje.poderAtaque} puntos de daño al enemigo!");

                                            if (enemigoVida > 0)
                                            {
                                                // Ataque del enemigo hacia el personaje
                                                personaje.puntosVida = personaje.puntosVida - ataqueEnemigo1;
                                                Console.WriteLine("");
                                                Console.WriteLine($"\t\t¡Has recibido {ataqueEnemigo1} de daño!");
                                            }
                                        }
                                        //Si el personaje logra derrotar al enemigo
                                        if (personaje.puntosVida > 0)
                                        {
                                            Console.WriteLine("\n¡Has derrotado al enemigo!");
                                            Console.WriteLine($"\n\n{personaje.MostrarInformacion()}");
                                            //Eleccion del cofre
                                            Console.WriteLine("¿Qué deseas hacer con el cofre ?\n1.Abrir\n2.Dejarlo Cerrado");
                                            int cofre = int.Parse(Console.ReadLine());
                                            //Cofre abierto llamando al metodo
                                            if (cofre == 1)
                                            {
                                                Personaje.AbrirCofreBosqueOscuro(personaje);
                                            }
                                            //Cofre cerrado
                                            else
                                            {
                                                Console.WriteLine("Decidiste dejar el cofre cerrado y continuar tu aventura.");
                                            }
                                            //Acumulacion de los enemigos derrotados
                                            enemigosDerrotados++;
                                        }
                                    }
                                    //Si escoge la opcion de huir
                                    else if (lucha == 2)
                                    {
                                        personaje.puntosVida = personaje.puntosVida - 10;
                                        Console.WriteLine($"\n\n{personaje.MostrarInformacion()}");
                                        cantidadBandidos++;
                                    }
                                    //Muestra el menu principal
                                    Personaje.MostrarMenuPrincipal(personaje, "Bosque Oscuro", enemigosDerrotados);
                                }
                                //Si logra derrotar al primer enemigo, se encuentra con un monstruo
                                else if (enemigosDerrotados == 1)
                                {
                                    Console.WriteLine($"\nOyeee {nickname}¡Te has encontrado con un MONSTRUO!");
                                    Random rand2 = new Random();
                                    //Declaracion del ataque random del enemigo
                                    int ataqueEnemigo2 = rand2.Next(10, 31);
                                    //Declaracion de la vida del enemigo
                                    enemigoVida = 50;

                                    //Se muestran las estadisticas del enemigo
                                    Console.WriteLine($"\n\tEL enemigo cuenta con {enemigoVida} puntos de vida y {ataqueEnemigo2} puntos de ataque.");
                                    //Eleccion de lucha o huir del enemigo
                                    Console.WriteLine("¿Qué deseas hacer?\n1. Luchar\n2. Huir");
                                    lucha = Convert.ToInt32(Console.ReadLine());

                                    //Si elige la opcion lucha
                                    if (lucha == 1)
                                    {
                                        while (personaje.puntosVida > 0 && enemigoVida > 0)
                                        {
                                            //El personaje le hace daño al enemigo
                                            enemigoVida = enemigoVida - personaje.poderAtaque;
                                            Console.WriteLine($"\t\t¡Le has infringido {personaje.poderAtaque} puntos de daño al enemigo!");

                                            //Si el enemigo sigue con vida
                                            if (enemigoVida > 0)
                                            {
                                                //El enemigo le hace daño al personaje
                                                personaje.puntosVida = personaje.puntosVida - ataqueEnemigo2;
                                                Console.WriteLine($"\t\t¡Has recibido {ataqueEnemigo2} de daño!");
                                            }
                                        }
                                        //Si el personaje sobrevive al ataque del enemigo
                                        if (personaje.puntosVida > 0)
                                        {
                                            Console.WriteLine("\n¡Has derrotado al enemigo!");
                                            Console.WriteLine($"\n\n{personaje.MostrarInformacion()}");
                                            //Eleccion del cofre
                                            Console.WriteLine("¿Qué deseas hacer con el cofre ?\n1.Abrir\n2.Dejarlo Cerrado");
                                            int cofre = int.Parse(Console.ReadLine());
                                            //Si elige abrirlo, se manda a llamar al metodo
                                            if (cofre == 1)
                                            {
                                                Personaje.AbrirCofreBosqueOscuro(personaje);
                                            }
                                            //Si decide dejarlo cerrado, no ocurre nada
                                            else
                                            {
                                                Console.WriteLine("Decidiste dejar el cofre cerrado y continuar tu aventura.");
                                            }
                                            //Acumulacion de los enemigos derrotados
                                            enemigosDerrotados++;
                                        }
                                    }
                                    //Si elige huir del enemigo
                                    else if (lucha == 2)
                                    {
                                        //Resta 10 puntos de vida
                                        personaje.puntosVida = personaje.puntosVida - 10;
                                        Console.WriteLine($"\n\n{personaje.MostrarInformacion()}");
                                        //Acumula la cantidad de monstruos que se permite 
                                        cantidadMonstruos++;
                                    }
                                    //Muestra el menu principal con las opciones correspondientes
                                    Personaje.MostrarMenuPrincipal(personaje, "Bosque Oscuro", enemigosDerrotados);
                                }
                                //Si logra derrotar a 2 enemigos 
                                else if (enemigosDerrotados == 2)
                                {
                                    Console.WriteLine($"Oyeee {nickname} ¡Te has encontrado con el JEFE FINAL !");
                                    Random rand3 = new Random();
                                    //Declaracion del ataque random del enemigo
                                    int ataqueEnemigo3 = rand3.Next(30, 51);
                                    //Declaracion de la vida del enemigo
                                    enemigoVida = 70;

                                    //Se muestran las estadisticas del enemigo
                                    Console.WriteLine($"\nEL enemigo cuenta con {enemigoVida} puntos de vida y {ataqueEnemigo3} puntos de ataque.");
                                    //Eleccion de lucha 
                                    Console.WriteLine("¿Qué deseas hacer?\n1. Luchar\n2. Huir");
                                    lucha = Convert.ToInt32(Console.ReadLine());

                                    //Si elige luchar 
                                    if (lucha == 1)
                                    {
                                        while (personaje.puntosVida > 0 && enemigoVida > 0)
                                        {
                                            //Ataque del personaje hacia el enemigo
                                            enemigoVida = enemigoVida - personaje.poderAtaque;
                                            Console.WriteLine($"\t\t¡Le has infringido {personaje.poderAtaque} puntos de daño al enemigo!");
                                            //Si el enemigo sigue con vida
                                            if (enemigoVida > 0)
                                            {
                                                // Ataque del enemigo hacia el personaje
                                                personaje.puntosVida = personaje.puntosVida - ataqueEnemigo3;
                                                Console.WriteLine($"\t\t¡Has recibido {ataqueEnemigo3} de daño!");
                                            }
                                        }
                                        //Si el personaje sobrevive al ataque del enemigo
                                        if (personaje.puntosVida > 0)
                                        {
                                            //Mostrar mensaje de que ha ganado el juego
                                            Console.WriteLine("\n¡Has derrotado al jefe final!!, has ganado hostia");
                                            Console.WriteLine($"\n\n {personaje.MostrarInformacion()}");
                                            //Acumulación de los Enemigos Derrotados
                                            enemigosDerrotados++;
                                        }
                                        //Si el personaje no logra sobrevivir a los ataques del enemigo
                                        else if (personaje.puntosVida < 0)
                                        {
                                            //Mostrar mensaje de que ha perdido el juego
                                            Console.WriteLine("\nHas sido derrotado.");
                                            Console.WriteLine("GAME OVER");
                                        }
                                    }
                                    //Si huye del enemigo
                                    else if (lucha == 2)
                                    {
                                        personaje.puntosVida = personaje.puntosVida - 10;
                                        Console.WriteLine($"\n\n{personaje.MostrarInformacion()}");
                                    }
                                    //Si no ingresa ningun dato valido
                                    else
                                    {
                                        Console.WriteLine("Ingresa un dato valido");
                                    }
                                }
                            }
                            //Para que termine el juego
                            jugar = false;
                            break;
                        case 2:
                            Console.WriteLine($"Cueva Sombria \t\t\t\t\t\t\t{personaje.MostrarInformacion()}");

                            while (personaje.puntosVida > 0 && enemigosDerrotados < 3)
                            {
                                Console.WriteLine($"¡Oye {nickname}! Te has encontrado un enemigo.");

                                if (enemigosDerrotados == 0)
                                {
                                    Console.WriteLine("¡Te has encontrado con un BANDIDO!");
                                    Random rand1 = new Random();
                                    //Declaracion del ataque random del enemigo
                                    int ataqueEnemigo1 = rand1.Next(5, 21);
                                    //Declaracion de la vida del enemigo
                                    enemigoVida = 30;

                                    //Se muestran las estadisticas del enemigo
                                    Console.WriteLine($"\nEL enemigo cuenta con {enemigoVida} puntos de vida y {ataqueEnemigo1} puntos de ataque.");
                                    Console.WriteLine("\n¿Qué deseas hacer?\n1. Luchar\n2. Huir");
                                    lucha = Convert.ToInt32(Console.ReadLine());

                                    //Proceso para la lucha
                                    if (lucha == 1)
                                    {
                                        while (personaje.puntosVida > 0 && enemigoVida > 0)
                                        {
                                            // Ataque del enemigo hacia el personaje
                                            personaje.puntosVida = personaje.puntosVida - ataqueEnemigo1;
                                            Console.WriteLine($"\t\t¡Has recibido {ataqueEnemigo1} de daño!");
                                            if (enemigoVida > 0)
                                            {
                                                // Ataque del personaje hacia el enemigo
                                                enemigoVida = enemigoVida - personaje.poderAtaque;
                                                Console.WriteLine($"\t\t\t¡Le has infringido {personaje.poderAtaque} puntos de daño al enemigo!");
                                            }
                                        }
                                        //Si el personaje logra derrotar al enemigo
                                        if (personaje.puntosVida > 0)
                                        {
                                            Console.WriteLine("\n\t¡Has derrotado al enemigo!");
                                            Console.WriteLine($"\n\n{personaje.MostrarInformacion()}");
                                            //Eleccion del cofre
                                            Console.WriteLine("\t\t\t\n¿Qué deseas hacer con el cofre ?\n1.Abrir\n2.Dejarlo Cerrado");
                                            int cofre = int.Parse(Console.ReadLine());
                                            //Cofre abierto llamando al metodo
                                            if (cofre == 1)
                                            {
                                                Personaje.AbrirCofreCueva(personaje);
                                            }
                                            //Cofre cerrado
                                            else
                                            {
                                                Console.WriteLine("Decidiste dejar el cofre cerrado y continuar tu aventura.");
                                            }
                                            //Acumulación de enemigos derrotados
                                            enemigosDerrotados++;
                                        }
                                    }
                                    //Si elige huir del enemigo
                                    else if (lucha == 2)
                                    {
                                        //El personaje pierde 10 puntos de vida
                                        personaje.puntosVida = personaje.puntosVida - 10;
                                        //Llama al método que muestra las estadísticas del personaje
                                        Console.WriteLine($"\n\n{personaje.MostrarInformacion()}");
                                    }
                                }
                                //Llama al método que muestra el menú principal
                                Personaje.MostrarMenuPrincipal(personaje, "Cueva Sombria", enemigosDerrotados);
                                //Si logra derrotar al primer enemigo, se encuentra con un monstruo
                                if (enemigosDerrotados == 1)
                                {
                                    Console.WriteLine($"¡Oye {nickname} ¡Te has encontrado con un MONSTRUO!");
                                    Random rand2 = new Random();
                                    //Declaracion del ataque random del enemigo
                                    int ataqueEnemigo2 = rand2.Next(10, 31);
                                    //Declaracion de la vida del enemigo
                                    enemigoVida = 50;

                                    //Se muestran las estadisticas del enemigo
                                    Console.WriteLine($"\nEL enemigo cuenta con {enemigoVida} puntos de vida y {ataqueEnemigo2} puntos de ataque.");
                                    Console.WriteLine("¿Qué deseas hacer?\n1. Luchar\n2. Huir");
                                    lucha = Convert.ToInt32(Console.ReadLine());
                                    //Proceso para la lucha
                                    if (lucha == 1)
                                    {
                                        while (personaje.puntosVida > 0 && enemigoVida > 0)
                                        {
                                            // Ataque del enemigo hacia el personaje
                                            personaje.puntosVida = personaje.puntosVida - ataqueEnemigo2;
                                            Console.WriteLine($"\t\t¡Has recibido {ataqueEnemigo2} de daño!");

                                            if (enemigoVida > 0 && personaje.puntosVida > 0)
                                            {
                                                // Ataque del personaje hacia el enemigo
                                                enemigoVida = enemigoVida - personaje.poderAtaque;
                                                Console.WriteLine($"\t\n¡Le has infringido {personaje.poderAtaque} puntos de daño al enemigo!");
                                            }
                                        }
                                        //Si el personaje logra derrotar al enemigo
                                        if (personaje.puntosVida > 0)
                                        {
                                            Console.WriteLine("\n¡Has derrotado al enemigo!");
                                            Console.WriteLine($"\n\n {personaje.MostrarInformacion()}");
                                            //Eleccion del cofre
                                            Console.WriteLine("¿Qué deseas hacer con el cofre ?\n1.Abrir\n2.Dejarlo Cerrado");
                                            int cofre = int.Parse(Console.ReadLine());

                                            //Cofre abierto llamando al metodo
                                            if (cofre == 1)
                                            {
                                                Personaje.AbrirCofreCueva(personaje);
                                            }
                                            //Cofre cerrado
                                            else
                                            {
                                                Console.WriteLine("Decidiste dejar el cofre cerrado y continuar tu aventura.");
                                            }
                                            //Acumulación de enemigos derrotados
                                            enemigosDerrotados++;
                                        }
                                    }
                                    //Si elige huir del enemigo
                                    else if (lucha == 2)
                                    {
                                        //El personaje pierde 10 puntos de vida
                                        personaje.puntosVida = personaje.puntosVida - 10;
                                        //Llama al método que muestra las estadísticas del personaje
                                        Console.WriteLine($"\n\t {personaje.MostrarInformacion()}");
                                    }
                                }
                                //Llama al método que muestra el menú principal
                                Personaje.MostrarMenuPrincipal(personaje, "Cueva Sombria", enemigosDerrotados);
                                //Si logra derrotar al segundo enemigo, se encuentra con el Jefe Final
                                if (enemigosDerrotados == 2)
                                {
                                    Console.WriteLine("¡Te has encontrado con un JEFE FINAL !");
                                    Random rand3 = new Random();
                                    //Declaracion del ataque random del enemigo
                                    int ataqueEnemigo3 = rand3.Next(30, 51);
                                    //Declaracion de la vida del enemigo
                                    enemigoVida = 70;

                                    //Se muestran las estadisticas del enemigo
                                    Console.WriteLine($"\nEL enemigo cuenta con {enemigoVida} puntos de vida y {ataqueEnemigo3} puntos de ataque.");
                                    Console.WriteLine("¿Qué deseas hacer?\n1. Luchar\n2. Huir");
                                    lucha = Convert.ToInt32(Console.ReadLine());
                                    //Proceso para la lucha
                                    if (lucha == 1)
                                    {
                                        while (personaje.puntosVida > 0 && enemigoVida > 0)
                                        {
                                            // Ataque del enemigo hacia el personaje
                                            personaje.puntosVida = personaje.puntosVida - ataqueEnemigo3;
                                            Console.WriteLine($"\t\t¡Has recibido {ataqueEnemigo3} de daño!");

                                            if (enemigoVida > 0 && personaje.puntosVida > 0)
                                            {
                                                // Ataque del personaje hacia el enemigo
                                                enemigoVida = enemigoVida - personaje.poderAtaque;
                                                Console.WriteLine($"\t\t¡Le has infringido {personaje.poderAtaque} puntos de daño al enemigo!");
                                            }
                                        }
                                        //Si el personaje logra derrotar al enemigo
                                        if (personaje.puntosVida > 0)
                                        {
                                            //Mostrar mensaje de que ha ganado el juego
                                            Console.WriteLine("\n¡Has derrotado al jefe final!!, has ganado hostia");
                                            Console.WriteLine($"\n\n {personaje.MostrarInformacion()}");
                                            //Acumulación de los Enemigos Derrotados
                                            enemigosDerrotados++;
                                        }
                                        //Si el personaje no logra sobrevivir a los ataques del enemigo
                                        else if (personaje.puntosVida < 0)
                                        {
                                            //Mostrar mensaje de que ha perdido el juego
                                            Console.WriteLine("\nHas sido derrotado.");
                                            Console.WriteLine("GAME OVER");
                                        }
                                    }
                                    //Si huye del enemigo
                                    else if (lucha == 2)
                                    {
                                        personaje.puntosVida = personaje.puntosVida - 10;
                                        Console.WriteLine($"\n\n {personaje.MostrarInformacion()}");
                                    }
                                }
                            }
                            //Para que termine el juego
                            jugar = false;
                            break;
                        case 3:
                            Console.WriteLine($"Camino de Piedra\t\t\t\t\t\t\t{personaje.MostrarInformacion()}");
                            while (personaje.puntosVida > 0 && enemigosDerrotados < 3)
                            {
                                Console.WriteLine($"¡Oye {nickname}! Te has encontrado un enemigo.");

                                if (enemigosDerrotados == 0)
                                {
                                    Console.WriteLine("¡Te has encontrado con un BANDIDO!");
                                    Random rand1 = new Random();
                                    //Declaracion del ataque random del enemigo
                                    int ataqueEnemigo1 = rand1.Next(5, 21);
                                    //Declaracion de la vida del enemigo
                                    enemigoVida = 30;

                                    //Se muestran las estadisticas del enemigo
                                    Console.WriteLine($"\nEL enemigo cuenta con {enemigoVida} puntos de vida y {ataqueEnemigo1} puntos de ataque.");
                                    //Eleccion de la lucha
                                    Console.WriteLine("¿Qué deseas hacer?\n1. Luchar\n2. Huir");
                                    lucha = Convert.ToInt32(Console.ReadLine());
                                    //Proceso para la lucha 
                                    if (lucha == 1)
                                    {
                                        while (personaje.puntosVida > 0 && enemigoVida > 0)
                                        {
                                            //Daño del personaje hacia el enemigo
                                            enemigoVida = enemigoVida - personaje.poderAtaque;
                                            Console.WriteLine($"\t\t¡Le has infringido {personaje.poderAtaque} puntos de daño al enemigo!");

                                            //Si el enemigo queda con vida
                                            if (enemigoVida > 0)
                                            {
                                                //Daño del enemigo hacia el personaje 
                                                personaje.puntosVida = personaje.puntosVida - ataqueEnemigo1;
                                                Console.WriteLine($"\t\t¡Has recibido {ataqueEnemigo1} de daño!");
                                            }
                                        }
                                        //Si el personaje queda con vida
                                        if (personaje.puntosVida > 0)
                                        {
                                            //Mostrar mensaje que ha derrotado al enemigo
                                            Console.WriteLine("\n¡Has derrotado al enemigo!");
                                            Console.WriteLine($"\n\n {personaje.MostrarInformacion()}");
                                            //Eleccion del cofre
                                            Console.WriteLine("¿Qué deseas hacer con el cofre ?\n1.Abrir\n2.Dejarlo Cerrado");
                                            int cofre = int.Parse(Console.ReadLine());
                                            ////Cofre abierto llamando al metodo
                                            if (cofre == 1)
                                            {
                                                Personaje.AbrirCofreCaminoPiedra(personaje);
                                            }
                                            //Cofre cerrado
                                            else
                                            {
                                                Console.WriteLine("Decidiste dejar el cofre cerrado y continuar tu aventura.");
                                            }
                                            //Aumento del contador de enemigos derrotados
                                            enemigosDerrotados++;
                                        }
                                    }
                                    //Si huye del enemigo
                                    else if (lucha == 2)
                                    {
                                        //Decremento en 10 puntos de salud
                                        personaje.puntosVida = personaje.puntosVida - 10;
                                        Console.WriteLine($"\n\n {personaje.MostrarInformacion()}");
                                    }
                                }
                                //Mostrar el menu principal
                                Personaje.MostrarMenuPrincipal(personaje, "Camino de Piedra", enemigosDerrotados);
                                //Si ha derrotado a un enemigo
                                if (enemigosDerrotados == 1)
                                {
                                    Console.WriteLine("¡Te has encontrado con un MONSTRUO!");
                                    //Declaracion del ataque random del enemigo
                                    Random rand2 = new Random();
                                    int ataqueEnemigo2 = rand2.Next(10, 31);
                                    //Declaracion de la vida del enemigo
                                    enemigoVida = 50;

                                    //Se muestran las estadisticas del enemigo
                                    Console.WriteLine($"\nEL enemigo cuenta con {enemigoVida} puntos de vida y {ataqueEnemigo2} puntos de ataque.");
                                    Console.WriteLine("¿Qué deseas hacer?\n1. Luchar\n2. Huir");
                                    lucha = Convert.ToInt32(Console.ReadLine());
                                    //Proceso para la lucha
                                    if (lucha == 1)
                                    {
                                        while (personaje.puntosVida > 0 && enemigoVida > 0)
                                        {
                                            // Ataque del personaje hacia el enemigo
                                            enemigoVida = enemigoVida - personaje.poderAtaque;
                                            Console.WriteLine($"\t\t¡Le has infringido {personaje.poderAtaque} puntos de daño al enemigo!");

                                            if (enemigoVida > 0)
                                            {
                                                // Ataque del enemigo hacia el personaje
                                                personaje.puntosVida = personaje.puntosVida - ataqueEnemigo2;
                                                Console.WriteLine($"\t\t¡Has recibido {ataqueEnemigo2} de daño!");
                                            }
                                        }
                                        //Si el personaje logra derrotar al enemigo
                                        if (personaje.puntosVida > 0)
                                        {
                                            Console.WriteLine("\n¡Has derrotado al enemigo!");
                                            Console.WriteLine($"\n\n{personaje.MostrarInformacion()}");
                                            //Elección del cofre
                                            Console.WriteLine("¿Qué deseas hacer con el cofre ?\n1.Abrir\n2.Dejarlo Cerrado");
                                            int cofre = int.Parse(Console.ReadLine());
                                            //Cofre abierto llamando al metodo
                                            if (cofre == 1)
                                            {
                                                Personaje.AbrirCofreCaminoPiedra(personaje);
                                            }
                                            //Cofre cerrado
                                            else
                                            {
                                                Console.WriteLine("Decidiste dejar el cofre cerrado y continuar tu aventura.");
                                            }
                                            //Acumulación de enemigos derrotados
                                            enemigosDerrotados++;
                                        }
                                    }
                                    //Si huye del enemigo
                                    else if (lucha == 2)
                                    {
                                        //El personaje pierde 10 puntos de vida
                                        personaje.puntosVida = personaje.puntosVida - 10;
                                        Console.WriteLine($"\n\n {personaje.MostrarInformacion()}");
                                    }
                                }
                                //Muestra el menu principal con los datos correspondientes
                                Personaje.MostrarMenuPrincipal(personaje, "Camino de Piedra", enemigosDerrotados);
                                //Si ha derrotado a dos enemigos
                                if (enemigosDerrotados == 2)
                                {
                                    Console.WriteLine("¡Te has encontrado con un JEFE FINAL !");
                                    Random rand3 = new Random();
                                    //Declaracion del ataque random del enemigo
                                    int ataqueEnemigo3 = rand3.Next(30, 51);
                                    //Declaracion de la vida del enemigo
                                    enemigoVida = 70;

                                    //Se muestran las estadisticas del enemigo
                                    Console.WriteLine($"\nEL enemigo cuenta con {enemigoVida} puntos de vida y {ataqueEnemigo3} puntos de ataque.");
                                    //Eleccion de lucha
                                    Console.WriteLine("¿Qué deseas hacer?\n1. Luchar\n2. Huir");
                                    lucha = Convert.ToInt32(Console.ReadLine());
                                    //Si escoge la opcion luchar
                                    if (lucha == 1)
                                    {
                                        while (personaje.puntosVida > 0 && enemigoVida > 0)
                                        {
                                            //Daño del personaje hacia el enemigo
                                            enemigoVida = enemigoVida - personaje.poderAtaque;
                                            Console.WriteLine($"\t\t¡Le has infringido {personaje.poderAtaque} puntos de daño al enemigo!");

                                            //Si el enemigo queda con vida
                                            if (enemigoVida > 0)
                                            {
                                                //Daño del enemigo hacia el personaje
                                                personaje.puntosVida = personaje.puntosVida - ataqueEnemigo3;
                                                Console.WriteLine($"\t\t¡Has recibido {ataqueEnemigo3} de daño!");
                                            }
                                        }
                                        //Si el personaje logra quedar con vida
                                        if (personaje.puntosVida > 0)
                                        {
                                            //Mostrar un mensaje que ha derrotado al jefe final
                                            Console.WriteLine("\n¡Has derrotado al jefe final!!, has ganado hostia");
                                            Console.WriteLine($"\n\n {personaje.MostrarInformacion()}");
                                            enemigosDerrotados++;
                                        }
                                    }
                                    //Si escoge la opcion de huir
                                    else if (lucha == 2)
                                    {
                                        //Decremento de 10 puntos de vida
                                        personaje.puntosVida = personaje.puntosVida - 10;
                                        Console.WriteLine($"\n\n {personaje.MostrarInformacion()}");
                                    }
                                }
                            }
                            //Si la vida del personaje es menor a 0
                            if (personaje.puntosVida < 0)
                            {
                                //Mostrar un mensaje que ha sido derrotado
                                Console.WriteLine("\nHas sido derrotado.");
                                Console.WriteLine("GAME OVER");
                            }
                            //Finaliza el juego
                            jugar = false;
                            break;
                        default:
                            //Si se ingresa otra opcion mayor a 3
                            Console.WriteLine("Ingresa un camino valido");
                            continue;
                    }
                }
            } while (jugar == true);
        }
    }

    //Clase para los personajes
    class Personaje
    {
        //Declaracion de las variables publicas
        public string Nombre { get; set; }
        public int puntosVida { get; set; }
        public int poderAtaque { get; set; }

        public Personaje(string nombre, int puntosVida, int poderAtaque)
        {
            Nombre = nombre;
            this.puntosVida = puntosVida;
            this.poderAtaque = poderAtaque;
        }
        public string MostrarInformacion()
        {
            //retorno de la informacion sobre los personajes
            return $"\n{Nombre}\n Puntos de vida: {puntosVida}\n Poder de ataque: {poderAtaque}";
        }

        //Método para probabilidad al abrir cofre en Bosque Oscuro
        public static void AbrirCofreBosqueOscuro(Personaje personaje)
        {
            //Declaracion del random para los cofres
            Random randc = new Random();
            int contenidocofre = randc.Next(1, 5);
            switch (contenidocofre)
            {
                case 1:
                    //Recupera 10 puntos de salud
                    Console.WriteLine("El cofre contenía Energía. Recuperas 10 puntos de salud.");
                    personaje.puntosVida += 10;
                    break;
                case 2:
                    //Aumento de ataque en 5 puntos
                    Console.WriteLine("¡Has encontrado Más Poder! Tu ataque aumenta en 5 puntos.");
                    personaje.poderAtaque += 5;
                    break;
                case 3:
                    //Perdida de 5 puntos de vida
                    Console.WriteLine("¡Oh no! El cofre tenía Veneno. Pierdes 5 puntos de salud.");
                    personaje.puntosVida -= 5;
                    break;
                case 4:
                    //Caida de la trampa, por lo que quita 10 puntos de vida
                    Console.WriteLine("¡Oh no! Has caido en una trampa. Pierdes 10 puntos de salud.");
                    personaje.puntosVida -= 10;
                    break;
            }
        }
        //Método para probabilidad al abrir cofre en Cueva Sombría
        public static void AbrirCofreCueva(Personaje personaje)
        {
            //Declaracion del random para los cofres
            Random randc = new Random();
            int contenidocofre = randc.Next(1, 4);
            switch (contenidocofre)
            {
                case 1:
                    //Recupera 10 puntos de salud
                    Console.WriteLine("El cofre contenía Energía. Recuperas 10 puntos de salud.");
                    personaje.puntosVida += 10;
                    break;
                case 2:
                    //Aumento de ataque en 5 puntos
                    Console.WriteLine("¡Has encontrado Más Poder! Tu ataque aumenta en 5 puntos.");
                    personaje.poderAtaque += 5;
                    break;
                case 3:
                    //Perdida de 5 puntos de vida
                    Console.WriteLine("¡Oh no! El cofre tenía Veneno. Pierdes 5 puntos de salud.");
                    personaje.puntosVida -= 5;
                    break;
            }
        }
        //Método para probabilidad al abrir cofre en Camino de Piedra
        public static void AbrirCofreCaminoPiedra(Personaje personaje)
        {
            //Declaracion del random para los cofres
            Random randc = new Random();
            int contenidocofre = randc.Next(1, 5);
            switch (contenidocofre)
            {
                case 1:
                    //Recupera 10 puntos de salud
                    Console.WriteLine("El cofre contenía Energía. Recuperas 10 puntos de salud.");
                    personaje.puntosVida += 10;
                    break;
                case 2:
                    //Aumento de ataque en 5 puntos
                    Console.WriteLine("¡Has encontrado Más Poder! Tu ataque aumenta en 5 puntos.");
                    personaje.poderAtaque += 5;
                    break;
                case 3:
                    //Perdida de salud en 5 puntos
                    Console.WriteLine("¡Oh no! El cofre tenía Veneno. Pierdes 5 puntos de salud.");
                    personaje.puntosVida -= 5;
                    break;
                case 4:
                    // Cofre vacio
                    Console.WriteLine("¡Oh no! El cofre está vacío");
                    break;
            }
        }
        public static void MostrarMenuPrincipal(Personaje personaje, string mapa, int enemigosDerrotados)
        {
            // Imprime la información del jugador y del mapa
            Console.WriteLine($"\n--- {mapa} ---");
            Console.WriteLine($"Puntos de salud: {personaje.puntosVida}");
            Console.WriteLine($"Poder de ataque: {personaje.poderAtaque}");
            Console.WriteLine($"Enemigos derrotados: {enemigosDerrotados}");

            // Muestra las opciones
            Console.WriteLine("\n¿Qué deseas hacer?");
            Console.WriteLine("1. Continuar la aventura");
            Console.WriteLine("2. Rendirse en la encrucijada (Game Over)");

            // Solicitar la opción del jugador
            int opcion = Convert.ToInt32(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    // Continuar la aventura
                    Console.WriteLine("¡Sigues adelante en tu aventura!");
                    // Llamar al siguiente combate o acción del mapa
                    break;
                case 2:
                    // Terminar la partida
                    Console.WriteLine("Has decidido rendirte. ¡Game Over!");
                    Environment.Exit(0);  // Termina el juego de manera exitosa
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, elige 1 o 2.");
                    break;
            }
        }
    }
}

